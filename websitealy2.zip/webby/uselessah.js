const loveLetter = `# My Dearest Love...

In your eyes I found my favorite constellation,
Your laughter - my personal symphony.
Every moment with you feels like...
A perfect verse in life's beautiful poetry.

**You are my:**
- 🌄 Morning sunshine
- 🌌 Midnight starlight
- 💖 Eternal heartbeat

*Forever Yours,*  
*[Your Name]*`;

document.addEventListener('DOMContentLoaded', () => {
    const heart = document.getElementById('solid-heart');
    const container = document.getElementById('message-container');
    const md = window.markdownIt({ html: true, linkify: true });
    let isOpen = false;

    // Initialize content
    document.getElementById('message').innerHTML = md.render(loveLetter);

    heart.addEventListener('click', () => {
        if(isOpen) return;
        isOpen = true;
        
        // Heart click animation
        heart.style.animation = 'heartPulse 0.6s ease-out';
        
        // Letter reveal animation
        container.classList.add('visible');
        
        // Add slight bounce at end
        setTimeout(() => {
            container.style.transform = 'translateY(10px) scale(1)';
            setTimeout(() => {
                container.style.transform = 'translateY(20px) scale(1)';
            }, 100);
        }, 600);
    });

    // Reset animation on heart
    heart.addEventListener('animationend', () => {
        heart.style.animation = 'heartPulse 2s ease-in-out infinite';
    });
});